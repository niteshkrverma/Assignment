<?php
class School_Model extends CI_Model
{
    function addschool($name,$email,$address,$city,$state,$phone,$image)
	{
		$sql=" INSERT INTO `data`(`id`, `name`, `email_id`, `address`, `city`,`state`, `contact_no`, `image`) VALUES ('','$name','$email','$address','$city','$state','$phone','$image')";
		if($this->db->query($sql))
		{
			return true;
		}
		else
		{
			return false;
		}
	}	
	function DisplaySchool()
	{
		$sql=$this->db->query("SELECT * FROM data");
		return $sql->result();
	}
}
?>