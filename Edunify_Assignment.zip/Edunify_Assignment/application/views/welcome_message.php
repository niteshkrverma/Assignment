<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<title>Home</title>
	<style>
		*{
  margin: 0;
  padding: 0;
  box-sizing: border-box;
  font-family: 'Poppins',sans-serif;
}
body{
  height: 100vh;
  display: flex;
  justify-content: center;
  /* align-items: center; */
  padding: 100px;
  background: linear-gradient(135deg, #71b7e6, #9b59b6);
}
		.Add{
			margin-right:20px;
			height: 40px;
			width: 100px;
			color: wheat;
			background-color: green;
			border-radius: 10px;
			text-decoration: none;
			text-align: center;
			
		}
		.Show{
			
			height: 40px;
			width: 100px;
			color: wheat;
			background-color: red;
			border-radius: 10px;
			text-decoration: none;
			text-align: center;
			
		}
	</style>
</head>
<body>
	<!-- <button class="Show">Add</button> -->
	<div class="Add"><a href="http://localhost/Edunify_Assignment/">Show</a></div>
	<div class="Show"><a href="http://localhost/Edunify_Assignment/index.php/Welcome/show">Show</a></div>
	
</body>
</html>