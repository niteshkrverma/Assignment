<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Show</title>
</head>
<style>
    body {
        margin: 0em;
        padding: 0em;
        font-family: roboto, sans-serif;
    }

    .head {
        display: flex;
        justify-content: center;
        margin-top: 2em;
    }

    .btn {
        border-radius: 0;
        font-size: 14px;
        font-weight: 700;
        color: #fff !important;
        padding: 13px 40px;
        text-transform: capitalize;
        background-color: #5cb85c;
        border-color: #4cae4c;
        margin-left: 3em;
        text-decoration: none;
        color: black;
    }

    .container1 {
        box-shadow: 0 30px 50px 0 rgb(1 1 1 / 18%);
        padding: 4rem 4rem;
        background-color: #fff;
        margin-top: 4em;
    }

    .sub_container {
        display: flex;
        flex-wrap: wrap;
        justify-content: space-around;
    }

    .demo1 {
        width: 300px;
        height: 500px;
        border: .5px solid #a2a2a2;
        ;
        border-radius: 15px 15px 15px 15px;
        margin-top: 10px;
        position: relative;
    }

    .img1 {

        border-radius: 15px 15px 0 0;
        width: 300px;
        height: 240px;
    }
    .img{
        width: 100%;
        height:100%;
        object-fit: cover;
        border-radius: 15px 15px 0 0;
       
    }
    .place {
        font-size: 16px;
        margin-left: 15px;
        color: #01bacf;
    }

    .name {
        font-size: 24px;
        margin-left: 15px;
        font-weight: bold;
    }

    .apply {
        width: 100%;
        height: 52px;
        background-color: #4cae4c;
        border: none;
        border-radius: 0 0 15px 15px;
        color: white;
        font-size: 16px;
        font-weight: 700;
        overflow: hidden;
        position: absolute;
        bottom: 0;
        left: 0;
    }
</style>

<body>
    <div class="head">
        <a href="addschool"> <button class="btn" id="show">Add School</button></a>
        <a href="showschool"> <button class="btn" id="show">Show School</button></a>
    </div>
    <div class="container1">
    
        <div class="sub_container">
        <?php foreach ($data as $result) { ?>
            <div class="demo1">
                <div class="img1">
                <img  src="<?php echo base_url($result->image); ?>" class="img">
                </div>
                <p class="place"><?php echo $result->state?></p>
                <p class="name"><?php echo $result->name?></p>
                <span style="margin-left: 15px; color:grey;"><?php echo $result->city?></span>
                <p class="name"><?php echo $result->address?></p><br><br>
                <button class="apply">Apply</button>
            </div>
            <?php } ?>
        </div>
</body>

</html>