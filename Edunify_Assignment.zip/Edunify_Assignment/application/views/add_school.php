<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Add</title>
</head>
<style>
  .container {
    max-width: 100%;
    width: 100%;
    background-color: #fff;
    padding: 25px 30px;
    border-radius: 5px;
    box-shadow: 0 5px 10px rgba(0, 0, 0, 0.15);
  }

  .container .title {
    font-size: 25px;
    font-weight: 500;
    position: relative;
  }

  .container .title::before {
    content: "";
    position: absolute;
    left: 0;
    bottom: 0;
    height: 3px;
    width: 30px;
    border-radius: 5px;
    /* background: linear-gradient(135deg, #71b7e6, #9b59b6); */
  }

  .content form .user-details {
    display: flex;
    flex-wrap: wrap;
    justify-content: space-between;
    margin: 20px 0 12px 0;
  }

  form .user-details .input-box {
    margin-bottom: 15px;
    width: calc(100% / 2 - 20px);
  }

  form .input-box span.details {
    display: block;
    font-weight: 500;
    margin-bottom: 5px;
  }

  .user-details .input-box input {
    height: 45px;
    width: 100%;
    outline: none;
    font-size: 16px;
    border-radius: 5px;
    padding-left: 15px;
    border: 1px solid #ccc;
    border-bottom-width: 2px;
    transition: all 0.3s ease;
  }

  .user-details .input-box input:focus,
  .user-details .input-box input:valid {
    border-color: #9b59b6;
  }

  form .button {
    height: 45px;
    margin: 35px 0;
  }

  form .button input {
    height: 100%;
    width: 100%;
    border-radius: 5px;
    border: none;
    color: #fff;
    font-size: 18px;
    font-weight: 500;
    letter-spacing: 1px;
    cursor: pointer;
    transition: all 0.3s ease;
    background: linear-gradient(135deg, #71b7e6, #9b59b6);
  }

  form .button input:hover {
    /* transform: scale(0.99); */
    background: linear-gradient(-135deg, #71b7e6, #9b59b6);
  }

  @media(max-width: 584px) {
    .container {
      max-width: 100%;
    }

    form .user-details .input-box {
      margin-bottom: 15px;
      width: 100%;
    }

    form .category {
      width: 100%;
    }

    .content form .user-details {
      max-height: 300px;
      overflow-y: scroll;
    }

    .user-details::-webkit-scrollbar {
      width: 5px;
    }
  }

  @media(max-width: 459px) {
    .container .content .category {
      flex-direction: column;
    }
  }

  .container1 {
    box-shadow: 0 30px 50px 0 rgb(1 1 1 / 18%);
    padding: 4rem 4rem;
    background-color: #fff;
    margin-top: 4em;
    display: flex;
    justify-content: center;
  }

  .head {
    display: flex;
    justify-content: center;
    margin-top: 2em;
  }

  .btn {
    border-radius: 0;
    font-size: 14px;
    font-weight: 700;
    color: #fff !important;
    padding: 13px 40px;
    text-transform: capitalize;
    background-color: #5cb85c;
    border-color: #4cae4c;
    margin-left: 3em;
    text-decoration: none;
    color: black;

  }
</style>

<body>
  <div class="head">
    <a href="addschool"> <button class="btn" id="show">Add School</button></a>
    <a href="showschool"> <button class="btn" id="show">Show School</button></a>
  </div>
  <div class="container1">

    <div class="container">
      <div class="title">Add School</div>
      <div class="content">
        <form method="POST" enctype="multipart/form-data">
          <div class="user-details">
            <div class="input-box">
              <span class="details">Name</span>
              <input type="text" name="name" placeholder="Enter School Name" required>
            </div>
            <div class="input-box">
              <span class="details">Address</span>
              <input type="text" name="address" na placeholder="Enter School Address" required>
            </div>
            <div class="input-box">
              <span class="details">City</span>
              <input type="text" name="city" placeholder="Enter City" required>
            </div>
            <div class="input-box">
              <span class="details">State</span>
              <input type="text" name="state" placeholder="Enter State" required>
            </div>
            <div class="input-box">
              <span class="details">Email</span>
              <input type="text" name="Email" placeholder="Enter Email-Id" required>
            </div>
            <div class="input-box">
              <span class="details">Phone Number</span>
              <input type="text" name="phone" placeholder="Enter Mobile Number" required>
            </div>
            <div class="input-box">
              <span class="details">Image</span>
              <input type="file" name="uploadimage" placeholder="Upload School Image" required>
            </div>

          </div>

          <div class="button">
            <input type="submit" name="submit" value="Add">
          </div>
        </form>
      </div>
    </div>
  </div>

</body>

</html>