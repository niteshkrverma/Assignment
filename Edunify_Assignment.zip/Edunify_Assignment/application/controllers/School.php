<?php
class School extends CI_Controller {
	function __construct()
	{
		parent::__construct();
		$this->load->model('School_Model');
		$this->load->library('form_validation');
	}

	public function index()
	{
		$this->load->view('welcome_message');
	}
	public function show()
	{
		$this->load->view('add_school');
	}
	function addschool()
	{
    	$this->load->view('add_school');
		if($this->input->post('submit'))
		{
			$name= $this->input->post('name');
			$email= $this->input->post('Email');
			$this->form_validation->set_rules('Email','Email','required|trim|is_unique[data.email_id]');
			$address= $this->input->post('address');	
			$phone= $this->input->post('phone');
			$city=$this->input->post('city');
			$state=$this->input->post('state');
			$image=$this->input->post('image');		
			$filename=$_FILES['uploadimage']['name'];
			$tmpname=$_FILES['uploadimage']['tmp_name'];
			$folder="image/".$filename;
			move_uploaded_file($tmpname,$folder);
			if($this->form_validation->run()==False)
			{
			
				echo '<script>alert("Email Already exits use different email");</script>';
            	
			}
			else
			{	
				if($this->School_Model->addschool($name,$email,$address,$city,$state,$phone,$folder))
				{
					echo "<script>alert('Add School Succesfully !')</script>";
					echo "<script>window.location.href='showschool'</script>";
				}
				else
				{
					echo "<script>alert('Failed')</script>";
				}
			}
		}
		
	}
	function showschool()
    {
    	$result['data']=$this->School_Model->DisplaySchool();
		$this->load->view('show_schools',$result);
    }
		
}
